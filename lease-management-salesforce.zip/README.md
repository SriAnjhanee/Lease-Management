# 🏘️ Lease Management - Salesforce Project

This Salesforce project is a **Lease Management System** to help landlords manage properties, tenants, payments, and rent reminders efficiently.

## 🚀 Features

- Custom Objects: Property, Tenant, Payment
- Lookup & Master-Detail Relationships
- Approval Process for vacating tenants
- Apex Trigger to enforce only one active tenant per property
- Monthly rent reminder emails via Scheduled Apex

[...Shortened for brevity in display...]