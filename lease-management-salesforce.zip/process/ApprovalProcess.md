# Approval Process

- Entry Criteria: Status = leave
- Initial Submission Action: Record Lock, Email Alert
- Email Template:
  Subject: Tenant Leaving Request
  Body: Please approve the tenant leaving request.