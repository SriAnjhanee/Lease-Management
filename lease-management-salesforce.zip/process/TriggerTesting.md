# Testing the Trigger

✅ Attempt to create a new Tenant with Status = stay on an already occupied Property:
- Expect Error: "Only one active tenant can exist for a property."