# Object Relationships

✅ Tenant__c → Property__c (Lookup)
✅ Payment__c → Tenant__c (Master-Detail)
✅ Payment__c → Property__c (Lookup)